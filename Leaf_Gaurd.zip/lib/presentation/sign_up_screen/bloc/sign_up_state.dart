// ignore_for_file: must_be_immutable

part of 'sign_up_bloc.dart';

/// Represents the state of SignUp in the application.
class SignUpState extends Equatable {
  SignUpState({
    this.nameEditTextController,
    this.emailEditTextController,
    this.passwordEditTextController,
    this.confirmpasswordEditTextController,
    this.signUpModelObj,
  });

  TextEditingController? nameEditTextController;

  TextEditingController? emailEditTextController;

  TextEditingController? passwordEditTextController;

  TextEditingController? confirmpasswordEditTextController;

  SignUpModel? signUpModelObj;

  @override
  List<Object?> get props => [
        nameEditTextController,
        emailEditTextController,
        passwordEditTextController,
        confirmpasswordEditTextController,
        signUpModelObj,
      ];

  SignUpState copyWith({
    TextEditingController? nameEditTextController,
    TextEditingController? emailEditTextController,
    TextEditingController? passwordEditTextController,
    TextEditingController? confirmpasswordEditTextController,
    SignUpModel? signUpModelObj,
  }) {
    return SignUpState(
      nameEditTextController:
          nameEditTextController ?? this.nameEditTextController,
      emailEditTextController:
          emailEditTextController ?? this.emailEditTextController,
      passwordEditTextController:
          passwordEditTextController ?? this.passwordEditTextController,
      confirmpasswordEditTextController: confirmpasswordEditTextController ??
          this.confirmpasswordEditTextController,
      signUpModelObj: signUpModelObj ?? this.signUpModelObj,
    );
  }
}
