import 'package:flutter/material.dart';
import 'package:farhan_s_application4/core/app_export.dart';
import 'package:farhan_s_application4/core/utils/validation_functions.dart';
import 'package:farhan_s_application4/widgets/app_bar/appbar_subtitle.dart';
import 'package:farhan_s_application4/widgets/app_bar/appbar_title_image.dart';
import 'package:farhan_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'package:farhan_s_application4/widgets/custom_elevated_button.dart';
import 'package:farhan_s_application4/widgets/custom_text_form_field.dart';
import 'bloc/sign_up_bloc.dart';
import 'models/sign_up_model.dart';

// ignore_for_file: must_be_immutable
class SignUpScreen extends StatelessWidget {
  SignUpScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<SignUpBloc>(
        create: (context) =>
            SignUpBloc(SignUpState(signUpModelObj: SignUpModel()))
              ..add(SignUpInitialEvent()),
        child: SignUpScreen());
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: Form(
                        key: _formKey,
                        child: Container(
                            width: double.maxFinite,
                            padding: EdgeInsets.symmetric(vertical: 18.v),
                            child: Column(children: [
                              SizedBox(height: 25.v),
                              SizedBox(
                                  height: 615.v,
                                  width: double.maxFinite,
                                  child: Stack(
                                      alignment: Alignment.center,
                                      children: [
                                        CustomImageView(
                                            imagePath:
                                                ImageConstant.imgGroupBlack900,
                                            height: 602.v,
                                            width: 379.h,
                                            alignment: Alignment.center),
                                        Align(
                                            alignment: Alignment.center,
                                            child: Padding(
                                                padding: EdgeInsets.symmetric(
                                                    horizontal: 52.h),
                                                child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      CustomImageView(
                                                          imagePath:
                                                              ImageConstant
                                                                  .imgEllipse1,
                                                          height: 133.adaptSize,
                                                          width: 133.adaptSize,
                                                          radius: BorderRadius
                                                              .circular(66.h)),
                                                      SizedBox(height: 20.v),
                                                      _buildNameEditText(
                                                          context),
                                                      SizedBox(height: 28.v),
                                                      _buildEmailEditText(
                                                          context),
                                                      SizedBox(height: 28.v),
                                                      _buildPasswordEditText(
                                                          context),
                                                      SizedBox(height: 28.v),
                                                      _buildConfirmpasswordEditText(
                                                          context),
                                                      SizedBox(height: 34.v),
                                                      _buildSignUpButton(
                                                          context)
                                                    ]))),
                                        _buildAppBar(context)
                                      ])),
                              SizedBox(height: 43.v),
                              Text("msg_terms_and_conditions".tr,
                                  style: CustomTextStyles
                                      .bodySmallBlack900ExtraLight)
                            ])))))));
  }

  /// Section Widget
  Widget _buildNameEditText(BuildContext context) {
    return BlocSelector<SignUpBloc, SignUpState, TextEditingController?>(
        selector: (state) => state.nameEditTextController,
        builder: (context, nameEditTextController) {
          return CustomTextFormField(
              controller: nameEditTextController,
              hintText: "lbl_name".tr,
              validator: (value) {
                if (!isText(value)) {
                  return "err_msg_please_enter_valid_text".tr;
                }
                return null;
              });
        });
  }

  /// Section Widget
  Widget _buildEmailEditText(BuildContext context) {
    return BlocSelector<SignUpBloc, SignUpState, TextEditingController?>(
        selector: (state) => state.emailEditTextController,
        builder: (context, emailEditTextController) {
          return CustomTextFormField(
              controller: emailEditTextController,
              hintText: "lbl_email_address".tr,
              textInputType: TextInputType.emailAddress,
              validator: (value) {
                if (value == null || (!isValidEmail(value, isRequired: true))) {
                  return "err_msg_please_enter_valid_email".tr;
                }
                return null;
              });
        });
  }

  /// Section Widget
  Widget _buildPasswordEditText(BuildContext context) {
    return BlocSelector<SignUpBloc, SignUpState, TextEditingController?>(
        selector: (state) => state.passwordEditTextController,
        builder: (context, passwordEditTextController) {
          return CustomTextFormField(
              controller: passwordEditTextController,
              hintText: "lbl_password2".tr,
              textInputType: TextInputType.visiblePassword,
              validator: (value) {
                if (value == null ||
                    (!isValidPassword(value, isRequired: true))) {
                  return "err_msg_please_enter_valid_password".tr;
                }
                return null;
              },
              obscureText: true);
        });
  }

  /// Section Widget
  Widget _buildConfirmpasswordEditText(BuildContext context) {
    return BlocSelector<SignUpBloc, SignUpState, TextEditingController?>(
        selector: (state) => state.confirmpasswordEditTextController,
        builder: (context, confirmpasswordEditTextController) {
          return CustomTextFormField(
              controller: confirmpasswordEditTextController,
              hintText: "msg_confirm_password".tr,
              textInputAction: TextInputAction.done,
              textInputType: TextInputType.visiblePassword,
              validator: (value) {
                if (value == null ||
                    (!isValidPassword(value, isRequired: true))) {
                  return "err_msg_please_enter_valid_password".tr;
                }
                return null;
              },
              obscureText: true);
        });
  }

  /// Section Widget
  Widget _buildSignUpButton(BuildContext context) {
    return CustomElevatedButton(
        width: 172.h,
        text: "lbl_sign_up".tr,
        onPressed: () {
          onTapSignUpButton(context);
        });
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        height: 52.v,
        centerTitle: true,
        title: Column(children: [
          Align(
              alignment: Alignment.centerLeft,
              child: SizedBox(width: double.maxFinite, child: Divider())),
          SizedBox(height: 11.v),
          Padding(
              padding: EdgeInsets.only(left: 18.h, right: 164.h),
              child: Row(children: [
                AppbarTitleImage(
                    imagePath: ImageConstant.img,
                    onTap: () {
                      onTapImage(context);
                    }),
                AppbarSubtitle(
                    text: "lbl_sign_up".tr,
                    margin: EdgeInsets.only(left: 107.h, top: 6.v, bottom: 4.v))
              ]))
        ]),
        styleType: Style.bgFill);
  }

  /// Navigates to the homePageScreen when the action is triggered.
  onTapSignUpButton(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.homePageScreen,
    );
  }

  /// Navigates to the logInScreen when the action is triggered.
  onTapImage(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.logInScreen,
    );
  }
}
