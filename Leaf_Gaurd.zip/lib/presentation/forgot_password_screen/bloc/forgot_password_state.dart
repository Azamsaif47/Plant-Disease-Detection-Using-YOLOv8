// ignore_for_file: must_be_immutable

part of 'forgot_password_bloc.dart';

/// Represents the state of ForgotPassword in the application.
class ForgotPasswordState extends Equatable {
  ForgotPasswordState({
    this.emailController,
    this.confirmationCodeController,
    this.newPasswordController,
    this.confirmPasswordController,
    this.forgotPasswordModelObj,
  });

  TextEditingController? emailController;

  TextEditingController? confirmationCodeController;

  TextEditingController? newPasswordController;

  TextEditingController? confirmPasswordController;

  ForgotPasswordModel? forgotPasswordModelObj;

  @override
  List<Object?> get props => [
        emailController,
        confirmationCodeController,
        newPasswordController,
        confirmPasswordController,
        forgotPasswordModelObj,
      ];

  ForgotPasswordState copyWith({
    TextEditingController? emailController,
    TextEditingController? confirmationCodeController,
    TextEditingController? newPasswordController,
    TextEditingController? confirmPasswordController,
    ForgotPasswordModel? forgotPasswordModelObj,
  }) {
    return ForgotPasswordState(
      emailController: emailController ?? this.emailController,
      confirmationCodeController:
          confirmationCodeController ?? this.confirmationCodeController,
      newPasswordController:
          newPasswordController ?? this.newPasswordController,
      confirmPasswordController:
          confirmPasswordController ?? this.confirmPasswordController,
      forgotPasswordModelObj:
          forgotPasswordModelObj ?? this.forgotPasswordModelObj,
    );
  }
}
