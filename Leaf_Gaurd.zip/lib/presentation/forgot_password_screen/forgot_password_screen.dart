import 'package:flutter/material.dart';
import 'package:farhan_s_application4/core/app_export.dart';
import 'package:farhan_s_application4/core/utils/validation_functions.dart';
import 'package:farhan_s_application4/widgets/app_bar/appbar_subtitle_one.dart';
import 'package:farhan_s_application4/widgets/app_bar/appbar_title_image.dart';
import 'package:farhan_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'package:farhan_s_application4/widgets/custom_elevated_button.dart';
import 'package:farhan_s_application4/widgets/custom_text_form_field.dart';
import 'bloc/forgot_password_bloc.dart';
import 'models/forgot_password_model.dart';

// ignore_for_file: must_be_immutable
class ForgotPasswordScreen extends StatelessWidget {
  ForgotPasswordScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<ForgotPasswordBloc>(
        create: (context) => ForgotPasswordBloc(
            ForgotPasswordState(forgotPasswordModelObj: ForgotPasswordModel()))
          ..add(ForgotPasswordInitialEvent()),
        child: ForgotPasswordScreen());
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(context),
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: Form(
                        key: _formKey,
                        child: Container(
                            width: double.maxFinite,
                            padding: EdgeInsets.symmetric(
                                horizontal: 14.h, vertical: 13.v),
                            child: Column(children: [
                              SizedBox(height: 8.v),
                              Text("msg_continue_using_your".tr,
                                  style: CustomTextStyles
                                      .titleLargeBlack900Medium),
                              SizedBox(height: 29.v),
                              _buildEmail(context),
                              SizedBox(height: 23.v),
                              _buildGetCode(context),
                              SizedBox(height: 49.v),
                              _buildConfirmationCode(context),
                              SizedBox(height: 31.v),
                              _buildNewPassword(context),
                              SizedBox(height: 31.v),
                              _buildConfirmPassword(context),
                              SizedBox(height: 31.v),
                              _buildChangePassword(context),
                              SizedBox(height: 45.v),
                              Align(
                                  alignment: Alignment.centerRight,
                                  child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Padding(
                                            padding: EdgeInsets.only(
                                                top: 74.v, bottom: 10.v),
                                            child: Text(
                                                "msg_terms_and_conditions".tr,
                                                style: CustomTextStyles
                                                    .bodySmallBlack900ExtraLight)),
                                        CustomImageView(
                                            imagePath:
                                                ImageConstant.imgCloseBlack900,
                                            height: 100.v,
                                            width: 68.h,
                                            margin: EdgeInsets.only(left: 72.h))
                                      ]))
                            ])))))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        centerTitle: true,
        title: Column(children: [
          SizedBox(
              height: 1.v,
              width: double.maxFinite,
              child: Stack(alignment: Alignment.center, children: [
                Align(
                    alignment: Alignment.center,
                    child: SizedBox(width: double.maxFinite, child: Divider())),
                Align(
                    alignment: Alignment.center,
                    child: SizedBox(width: double.maxFinite, child: Divider()))
              ])),
          SizedBox(height: 10.v),
          Padding(
              padding: EdgeInsets.only(left: 17.h, right: 132.h),
              child: Row(children: [
                AppbarTitleImage(
                    imagePath: ImageConstant.img,
                    onTap: () {
                      onTapImage(context);
                    }),
                AppbarSubtitleOne(
                    text: "lbl_forgot_password".tr,
                    margin: EdgeInsets.only(left: 78.h, top: 9.v, bottom: 7.v))
              ]))
        ]),
        styleType: Style.bgFill_2);
  }

  /// Section Widget
  Widget _buildEmail(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 39.h),
        child: BlocSelector<ForgotPasswordBloc, ForgotPasswordState,
                TextEditingController?>(
            selector: (state) => state.emailController,
            builder: (context, emailController) {
              return CustomTextFormField(
                  controller: emailController,
                  hintText: "lbl_email".tr,
                  textInputType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null ||
                        (!isValidEmail(value, isRequired: true))) {
                      return "err_msg_please_enter_valid_email".tr;
                    }
                    return null;
                  });
            }));
  }

  /// Section Widget
  Widget _buildGetCode(BuildContext context) {
    return CustomElevatedButton(
        height: 31.v,
        width: 132.h,
        text: "lbl_get_code".tr,
        buttonStyle: CustomButtonStyles.fillPrimaryTL15,
        buttonTextStyle: CustomTextStyles.titleMediumWhiteA700);
  }

  /// Section Widget
  Widget _buildConfirmationCode(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 39.h),
        child: BlocSelector<ForgotPasswordBloc, ForgotPasswordState,
                TextEditingController?>(
            selector: (state) => state.confirmationCodeController,
            builder: (context, confirmationCodeController) {
              return CustomTextFormField(
                  width: 190.h,
                  controller: confirmationCodeController,
                  hintText: "msg_confirmation_code".tr,
                  alignment: Alignment.centerLeft);
            }));
  }

  /// Section Widget
  Widget _buildNewPassword(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 39.h),
        child: BlocSelector<ForgotPasswordBloc, ForgotPasswordState,
                TextEditingController?>(
            selector: (state) => state.newPasswordController,
            builder: (context, newPasswordController) {
              return CustomTextFormField(
                  controller: newPasswordController,
                  hintText: "lbl_new_password".tr,
                  textInputType: TextInputType.visiblePassword,
                  validator: (value) {
                    if (value == null ||
                        (!isValidPassword(value, isRequired: true))) {
                      return "err_msg_please_enter_valid_password".tr;
                    }
                    return null;
                  },
                  obscureText: true);
            }));
  }

  /// Section Widget
  Widget _buildConfirmPassword(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 39.h),
        child: BlocSelector<ForgotPasswordBloc, ForgotPasswordState,
                TextEditingController?>(
            selector: (state) => state.confirmPasswordController,
            builder: (context, confirmPasswordController) {
              return CustomTextFormField(
                  controller: confirmPasswordController,
                  hintText: "msg_confirm_password".tr,
                  textInputAction: TextInputAction.done,
                  textInputType: TextInputType.visiblePassword,
                  validator: (value) {
                    if (value == null ||
                        (!isValidPassword(value, isRequired: true))) {
                      return "err_msg_please_enter_valid_password".tr;
                    }
                    return null;
                  },
                  obscureText: true);
            }));
  }

  /// Section Widget
  Widget _buildChangePassword(BuildContext context) {
    return CustomElevatedButton(
        width: 172.h,
        text: "lbl_change_password".tr,
        buttonTextStyle: CustomTextStyles.titleSmallWhiteA700,
        onPressed: () {
          onTapChangePassword(context);
        });
  }

  /// Navigates to the logInScreen when the action is triggered.
  onTapImage(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.logInScreen,
    );
  }

  /// Navigates to the homePageScreen when the action is triggered.
  onTapChangePassword(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.homePageScreen,
    );
  }
}
