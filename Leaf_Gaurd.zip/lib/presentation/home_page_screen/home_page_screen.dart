import 'package:flutter/material.dart';
import 'package:farhan_s_application4/core/app_export.dart';
import 'package:farhan_s_application4/widgets/app_bar/appbar_title.dart';
import 'package:farhan_s_application4/widgets/app_bar/appbar_title_image.dart';
import 'package:farhan_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'bloc/home_page_bloc.dart';
import 'models/home_page_model.dart';

class HomePageScreen extends StatelessWidget {
  const HomePageScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<HomePageBloc>(
        create: (context) =>
            HomePageBloc(HomePageState(homePageModelObj: HomePageModel()))
              ..add(HomePageInitialEvent()),
        child: HomePageScreen());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<HomePageBloc, HomePageState>(builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              appBar: _buildAppBar(context),
              body: SizedBox(
                  width: SizeUtils.width,
                  child: SingleChildScrollView(
                      padding: EdgeInsets.only(top: 14.v),
                      child: Column(children: [
                        _buildEleven(context),
                        SizedBox(height: 31.v),
                        _buildFourteen(context),
                        SizedBox(height: 27.v),
                        _buildThirtySeven(context)
                      ])))));
    });
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        centerTitle: true,
        title: Column(children: [
          SizedBox(width: double.maxFinite, child: Divider()),
          SizedBox(height: 10.v),
          Padding(
              padding: EdgeInsets.only(left: 15.h, right: 16.h),
              child: Row(children: [
                AppbarTitleImage(
                    imagePath: ImageConstant.imgClose,
                    onTap: () {
                      onTapClose(context);
                    }),
                AppbarTitle(
                    text: "lbl_leaf_guardian".tr,
                    margin: EdgeInsets.only(left: 79.h, top: 6.v, bottom: 5.v)),
                AppbarTitleImage(
                    imagePath: ImageConstant.imgLock,
                    margin: EdgeInsets.only(left: 84.h),
                    onTap: () {
                      onTapLock(context);
                    })
              ]))
        ]),
        styleType: Style.bgFill_1);
  }

  /// Section Widget
  Widget _buildEleven(BuildContext context) {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 86.h, vertical: 14.v),
        decoration: AppDecoration.fillSecondaryContainer,
        child: Column(children: [
          SizedBox(height: 7.v),
          SizedBox(
              width: 237.h,
              child: Text("msg_illuminate_the_ailment".tr,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: CustomTextStyles.headlineSmallBold))
        ]));
  }

  /// Section Widget
  Widget _buildFourteen(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 28.h),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Container(
              padding: EdgeInsets.symmetric(vertical: 11.v),
              decoration: AppDecoration.fillOnPrimaryContainer
                  .copyWith(borderRadius: BorderRadiusStyle.roundedBorder13),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                SizedBox(height: 26.v),
                CustomImageView(
                    imagePath: ImageConstant.imgCameraMinimali,
                    height: 68.adaptSize,
                    width: 68.adaptSize),
                SizedBox(height: 36.v),
                SizedBox(
                    width: 148.h, child: Divider(color: appTheme.whiteA700)),
                Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                        padding: EdgeInsets.only(left: 21.h),
                        child: Text("msg_describe_a_disease".tr,
                            style: CustomTextStyles.bodySmallBlack900Regular))),
                SizedBox(height: 8.v),
                Text("lbl_camera".tr, style: theme.textTheme.labelMedium)
              ])),
          Container(
              padding: EdgeInsets.symmetric(vertical: 10.v),
              decoration: AppDecoration.fillOnPrimaryContainer
                  .copyWith(borderRadius: BorderRadiusStyle.roundedBorder13),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                SizedBox(height: 34.v),
                CustomImageView(
                    imagePath: ImageConstant.imgOnprimary,
                    height: 53.adaptSize,
                    width: 53.adaptSize),
                SizedBox(height: 44.v),
                SizedBox(
                    width: 148.h, child: Divider(color: appTheme.whiteA700)),
                Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                        padding: EdgeInsets.only(left: 21.h),
                        child: Text("msg_describe_a_disease".tr,
                            style: CustomTextStyles.bodySmallBlack900Regular))),
                SizedBox(height: 9.v),
                Text("msg_upload_from_gallery".tr,
                    style: theme.textTheme.labelMedium)
              ]))
        ]));
  }

  /// Section Widget
  Widget _buildThirtySeven(BuildContext context) {
    return SizedBox(
        height: 306.v,
        width: double.maxFinite,
        child: Stack(alignment: Alignment.bottomRight, children: [
          CustomImageView(
              imagePath: ImageConstant.imgFrame,
              height: 155.v,
              width: 158.h,
              alignment: Alignment.bottomLeft,
              margin: EdgeInsets.only(bottom: 26.v)),
          Align(
              alignment: Alignment.bottomRight,
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CustomImageView(
                        imagePath: ImageConstant.imgGroupCyan900,
                        height: 102.v,
                        width: 69.h,
                        margin: EdgeInsets.only(top: 20.v, bottom: 13.v)),
                    CustomImageView(
                        imagePath: ImageConstant.imgGroupRed700,
                        height: 135.v,
                        width: 160.h,
                        margin: EdgeInsets.only(left: 13.h))
                  ])),
          CustomImageView(
              imagePath: ImageConstant.imgVectorOrange100,
              height: 133.v,
              width: 57.h,
              alignment: Alignment.topLeft,
              margin: EdgeInsets.only(top: 79.v)),
          Align(
              alignment: Alignment.topLeft,
              child: Padding(
                  padding: EdgeInsets.only(left: 44.h, top: 6.v, right: 334.h),
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("lbl_history".tr,
                            style: theme.textTheme.labelMedium),
                        SizedBox(height: 4.v),
                        Text("lbl_today".tr,
                            style: CustomTextStyles.bodySmallBlack900),
                        SizedBox(height: 2.v),
                        CustomImageView(
                            imagePath: ImageConstant.imgCloseWhiteA700,
                            height: 15.adaptSize,
                            width: 15.adaptSize,
                            margin: EdgeInsets.only(left: 4.h)),
                        SizedBox(height: 7.v),
                        CustomImageView(
                            imagePath: ImageConstant.imgCloseWhiteA700,
                            height: 15.adaptSize,
                            width: 15.adaptSize,
                            margin: EdgeInsets.only(left: 4.h))
                      ]))),
          Align(
              alignment: Alignment.topLeft,
              child: Padding(
                  padding: EdgeInsets.only(left: 44.h, top: 84.v),
                  child: Text("lbl_yesterday".tr,
                      style: CustomTextStyles.bodySmallBlack900))),
          CustomImageView(
              imagePath: ImageConstant.imgCloseWhiteA700,
              height: 15.adaptSize,
              width: 15.adaptSize,
              alignment: Alignment.topLeft,
              margin: EdgeInsets.only(left: 48.h, top: 96.v)),
          Align(
              alignment: Alignment.topCenter,
              child: SizedBox(
                  height: 157.v,
                  width: 357.h,
                  child: Stack(alignment: Alignment.center, children: [
                    CustomImageView(
                        imagePath: ImageConstant.imgEllipse3,
                        height: 15.adaptSize,
                        width: 15.adaptSize,
                        radius: BorderRadius.circular(7.h),
                        alignment: Alignment.bottomLeft,
                        margin: EdgeInsets.only(left: 20.h, bottom: 24.v)),
                    Align(
                        alignment: Alignment.center,
                        child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 15.h, vertical: 9.v),
                            decoration: AppDecoration.fillOnPrimaryContainer1
                                .copyWith(
                                    borderRadius:
                                        BorderRadiusStyle.roundedBorder7),
                            child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(height: 31.v),
                                  Padding(
                                      padding: EdgeInsets.only(left: 29.h),
                                      child: RichText(
                                          text: TextSpan(children: [
                                            TextSpan(
                                                text: "lbl_leaf_spot".tr,
                                                style:
                                                    theme.textTheme.labelSmall),
                                            TextSpan(
                                                text: "msg_detected_through".tr,
                                                style:
                                                    theme.textTheme.bodySmall)
                                          ]),
                                          textAlign: TextAlign.left)),
                                  SizedBox(height: 12.v),
                                  Align(
                                      alignment: Alignment.center,
                                      child: RichText(
                                          text: TextSpan(children: [
                                            TextSpan(
                                                text: "lbl_antracnose".tr,
                                                style:
                                                    theme.textTheme.labelSmall),
                                            TextSpan(
                                                text:
                                                    "msg_detected_through2".tr,
                                                style:
                                                    theme.textTheme.bodySmall)
                                          ]),
                                          textAlign: TextAlign.left)),
                                  SizedBox(height: 9.v),
                                  Divider(color: appTheme.whiteA700),
                                  SizedBox(height: 17.v),
                                  Align(
                                      alignment: Alignment.center,
                                      child: RichText(
                                          text: TextSpan(children: [
                                            TextSpan(
                                                text: "lbl_mosaic_virus".tr,
                                                style:
                                                    theme.textTheme.labelSmall),
                                            TextSpan(
                                                text:
                                                    "msg_detected_through3".tr,
                                                style:
                                                    theme.textTheme.bodySmall)
                                          ]),
                                          textAlign: TextAlign.left)),
                                  SizedBox(height: 12.v),
                                  Padding(
                                      padding: EdgeInsets.only(left: 29.h),
                                      child: RichText(
                                          text: TextSpan(children: [
                                            TextSpan(
                                                text: "lbl_blight".tr,
                                                style:
                                                    theme.textTheme.labelSmall),
                                            TextSpan(
                                                text:
                                                    "msg_detected_through4".tr,
                                                style:
                                                    theme.textTheme.bodySmall)
                                          ]),
                                          textAlign: TextAlign.left)),
                                  SizedBox(height: 6.v),
                                  Align(
                                      alignment: Alignment.centerRight,
                                      child: Text("lbl_load_more".tr,
                                          style: CustomTextStyles
                                              .urbanistBlack900
                                              .copyWith(
                                                  decoration: TextDecoration
                                                      .underline)))
                                ])))
                  ])))
        ]));
  }

  /// Navigates to the previous screen.
  onTapClose(BuildContext context) {
    NavigatorService.goBack();
  }

  /// Navigates to the profileScreen when the action is triggered.
  onTapLock(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.profileScreen,
    );
  }
}
