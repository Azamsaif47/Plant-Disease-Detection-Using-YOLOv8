import 'package:flutter/material.dart';
import 'package:farhan_s_application4/core/app_export.dart';
import 'package:farhan_s_application4/widgets/app_bar/appbar_subtitle.dart';
import 'package:farhan_s_application4/widgets/app_bar/appbar_title_image.dart';
import 'package:farhan_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'bloc/profile_bloc.dart';
import 'models/profile_model.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<ProfileBloc>(
        create: (context) =>
            ProfileBloc(ProfileState(profileModelObj: ProfileModel()))
              ..add(ProfileInitialEvent()),
        child: ProfileScreen());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ProfileBloc, ProfileState>(builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              appBar: _buildAppBar(context),
              body: Container(
                  width: double.maxFinite,
                  padding:
                      EdgeInsets.symmetric(horizontal: 41.h, vertical: 12.v),
                  child: Column(children: [
                    SizedBox(height: 9.v),
                    CustomImageView(
                        imagePath: ImageConstant.imgEllipse1,
                        height: 133.adaptSize,
                        width: 133.adaptSize,
                        radius: BorderRadius.circular(66.h)),
                    SizedBox(height: 16.v),
                    Text("lbl_azam_saif".tr,
                        style: CustomTextStyles.headlineSmallMedium),
                    SizedBox(height: 1.v),
                    Text("msg_azamsaif123_gmail_com".tr,
                        style: CustomTextStyles.bodyMediumLight),
                    SizedBox(height: 7.v),
                    Divider(),
                    SizedBox(height: 42.v),
                    SizedBox(
                        height: 40.v,
                        width: 316.h,
                        child:
                            Stack(alignment: Alignment.bottomLeft, children: [
                          CustomImageView(
                              imagePath: ImageConstant.imgGroup14,
                              height: 40.v,
                              width: 316.h,
                              alignment: Alignment.center),
                          Align(
                              alignment: Alignment.bottomLeft,
                              child: Padding(
                                  padding:
                                      EdgeInsets.only(left: 51.h, bottom: 7.v),
                                  child: Text("lbl_settings".tr,
                                      style: theme.textTheme.titleMedium)))
                        ])),
                    SizedBox(height: 28.v),
                    SizedBox(
                        height: 37.v,
                        width: 316.h,
                        child:
                            Stack(alignment: Alignment.bottomLeft, children: [
                          Align(
                              alignment: Alignment.center,
                              child: Container(
                                  height: 37.v,
                                  width: 316.h,
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 11.h, vertical: 2.v),
                                  decoration: AppDecoration
                                      .fillOnPrimaryContainer2
                                      .copyWith(
                                          borderRadius: BorderRadiusStyle
                                              .roundedBorder10),
                                  child: CustomImageView(
                                      imagePath:
                                          ImageConstant.imgSupportSvgrepoCom,
                                      height: 32.adaptSize,
                                      width: 32.adaptSize,
                                      alignment: Alignment.centerLeft))),
                          Align(
                              alignment: Alignment.bottomLeft,
                              child: Padding(
                                  padding:
                                      EdgeInsets.only(left: 54.h, bottom: 6.v),
                                  child: Text("msg_costumer_support".tr,
                                      style: theme.textTheme.titleMedium)))
                        ])),
                    SizedBox(height: 28.v),
                    SizedBox(
                        height: 37.v,
                        width: 316.h,
                        child:
                            Stack(alignment: Alignment.centerLeft, children: [
                          Align(
                              alignment: Alignment.center,
                              child: Container(
                                  height: 37.v,
                                  width: 316.h,
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 14.h, vertical: 7.v),
                                  decoration: AppDecoration
                                      .fillOnPrimaryContainer2
                                      .copyWith(
                                          borderRadius: BorderRadiusStyle
                                              .roundedBorder10),
                                  child: CustomImageView(
                                      imagePath: ImageConstant.imgSearch,
                                      height: 23.adaptSize,
                                      width: 23.adaptSize,
                                      alignment: Alignment.centerLeft))),
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                  padding: EdgeInsets.only(left: 49.h),
                                  child: Text("lbl_share".tr,
                                      style: theme.textTheme.titleMedium)))
                        ])),
                    SizedBox(height: 28.v),
                    SizedBox(
                        height: 37.v,
                        width: 316.h,
                        child:
                            Stack(alignment: Alignment.centerLeft, children: [
                          Align(
                              alignment: Alignment.center,
                              child: Container(
                                  height: 37.v,
                                  width: 316.h,
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 11.h, vertical: 2.v),
                                  decoration: AppDecoration
                                      .fillOnPrimaryContainer2
                                      .copyWith(
                                          borderRadius: BorderRadiusStyle
                                              .roundedBorder10),
                                  child: CustomImageView(
                                      imagePath:
                                          ImageConstant.imgAboutSvgrepoCom,
                                      height: 31.adaptSize,
                                      width: 31.adaptSize,
                                      alignment: Alignment.bottomLeft))),
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                  padding: EdgeInsets.only(left: 51.h),
                                  child: Text("lbl_about_us".tr,
                                      style: theme.textTheme.titleMedium)))
                        ])),
                    SizedBox(height: 91.v),
                    Text("msg_terms_and_conditions".tr,
                        style: CustomTextStyles.bodySmallBlack900ExtraLight),
                    SizedBox(height: 2.v),
                    Text("lbl_privacy_policy".tr,
                        style: CustomTextStyles.labelMediumMedium)
                  ]))));
    });
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        centerTitle: true,
        title: Column(children: [
          Align(
              alignment: Alignment.centerLeft,
              child: SizedBox(width: double.maxFinite, child: Divider())),
          SizedBox(height: 11.v),
          Padding(
              padding: EdgeInsets.only(left: 21.h, right: 173.h),
              child: Row(children: [
                AppbarTitleImage(
                    imagePath: ImageConstant.img,
                    onTap: () {
                      onTapImage(context);
                    }),
                AppbarSubtitle(
                    text: "lbl_profile".tr,
                    margin: EdgeInsets.only(left: 113.h, top: 3.v, bottom: 7.v))
              ]))
        ]),
        styleType: Style.bgFill_1);
  }

  /// Navigates to the homePageScreen when the action is triggered.
  onTapImage(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.homePageScreen,
    );
  }
}
