import 'package:flutter/material.dart';
import 'package:farhan_s_application4/core/app_export.dart';
import 'bloc/splash_bloc.dart';
import 'models/splash_model.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<SplashBloc>(
        create: (context) =>
            SplashBloc(SplashState(splashModelObj: SplashModel()))
              ..add(SplashInitialEvent()),
        child: SplashScreen());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SplashBloc, SplashState>(builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              backgroundColor: appTheme.lightGreen300,
              body: SizedBox(
                  width: double.maxFinite,
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 6.v),
                        SizedBox(
                            height: 474.v,
                            width: double.maxFinite,
                            child: Stack(
                                alignment: Alignment.bottomCenter,
                                children: [
                                  CustomImageView(
                                      imagePath: ImageConstant.imgGroup,
                                      height: 318.v,
                                      width: 414.h,
                                      alignment: Alignment.topCenter),
                                  Align(
                                      alignment: Alignment.bottomCenter,
                                      child: Padding(
                                          padding: EdgeInsets.only(
                                              left: 51.h, right: 62.h),
                                          child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Text("lbl_welcome".tr,
                                                    style: theme.textTheme
                                                        .displayMedium),
                                                Text("lbl_to".tr,
                                                    style: theme.textTheme
                                                        .displayMedium),
                                                SizedBox(
                                                    width: 300.h,
                                                    child: Text(
                                                        "lbl_leaf_guardian".tr,
                                                        maxLines: 1,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: CustomTextStyles
                                                            .displayMediumUchen))
                                              ])))
                                ])),
                        SizedBox(height: 91.v),
                        CustomImageView(
                            imagePath: ImageConstant.imgVector,
                            height: 163.v,
                            width: 83.h,
                            margin: EdgeInsets.only(left: 22.h))
                      ]))));
    });
  }
}
