import 'package:flutter/material.dart';
import 'package:farhan_s_application4/core/app_export.dart';
import 'package:farhan_s_application4/widgets/app_bar/appbar_subtitle_one.dart';
import 'package:farhan_s_application4/widgets/app_bar/appbar_title_image.dart';
import 'package:farhan_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'package:farhan_s_application4/widgets/custom_checkbox_button.dart';
import 'package:farhan_s_application4/widgets/custom_elevated_button.dart';
import 'package:farhan_s_application4/widgets/custom_text_form_field.dart';
import 'bloc/premium_bloc.dart';
import 'models/premium_model.dart';

class PremiumScreen extends StatelessWidget {
  const PremiumScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<PremiumBloc>(
        create: (context) =>
            PremiumBloc(PremiumState(premiumModelObj: PremiumModel()))
              ..add(PremiumInitialEvent()),
        child: PremiumScreen());
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(context),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(vertical: 11.v),
                child: Column(children: [
                  _buildEleven(context),
                  SizedBox(height: 44.v),
                  _buildThirtyThree(context),
                  SizedBox(height: 39.v),
                  CustomElevatedButton(
                      width: 213.h, text: "lbl_buy_premium".tr),
                  Spacer(),
                  SizedBox(height: 15.v),
                  Text("msg_terms_and_conditions".tr,
                      style: CustomTextStyles.bodySmallBlack900ExtraLight)
                ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        centerTitle: true,
        title: Column(children: [
          Align(
              alignment: Alignment.centerLeft,
              child: SizedBox(width: double.maxFinite, child: Divider())),
          SizedBox(height: 11.v),
          Padding(
              padding: EdgeInsets.only(left: 22.h, right: 132.h),
              child: Row(children: [
                AppbarTitleImage(
                    imagePath: ImageConstant.img,
                    onTap: () {
                      onTapImage(context);
                    }),
                AppbarSubtitleOne(
                    text: "lbl_premium_version".tr,
                    margin: EdgeInsets.only(left: 70.h, top: 4.v, bottom: 11.v))
              ]))
        ]),
        styleType: Style.bgFill_1);
  }

  /// Section Widget
  Widget _buildEleven(BuildContext context) {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 62.h, vertical: 14.v),
        decoration: AppDecoration.fillOrange,
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
              width: 237.h,
              margin: EdgeInsets.only(left: 26.h, right: 25.h),
              child: Text("msg_ai_safeguarding".tr,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: CustomTextStyles.headlineSmallBold)),
          SizedBox(height: 20.v),
          Text("msg_plant_care_now".tr, style: theme.textTheme.bodyLarge),
          SizedBox(height: 1.v),
          Container(
              decoration: AppDecoration.outlineBlack,
              child: Text("lbl_leaf_guardian".tr,
                  style: CustomTextStyles.headlineSmallUchenLightgreen700)),
          SizedBox(height: 4.v)
        ]));
  }

  /// Section Widget
  Widget _buildThirtyThree(BuildContext context) {
    return Container(
        margin: EdgeInsets.only(left: 25.h, right: 29.h),
        padding: EdgeInsets.symmetric(horizontal: 27.h, vertical: 14.v),
        decoration: AppDecoration.fillOnPrimaryContainer1
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder10),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
              padding: EdgeInsets.only(left: 11.h, right: 2.h),
              child: BlocSelector<PremiumBloc, PremiumState, bool?>(
                  selector: (state) => state.noAds,
                  builder: (context, noAds) {
                    return CustomCheckboxButton(
                        width: 293.h,
                        text: "lbl_no_ads".tr,
                        value: noAds,
                        padding: EdgeInsets.symmetric(vertical: 2.v),
                        isRightCheck: true,
                        onChange: (value) {
                          context
                              .read<PremiumBloc>()
                              .add(ChangeCheckBoxEvent(value: value));
                        });
                  })),
          SizedBox(height: 13.v),
          Divider(color: appTheme.whiteA700, endIndent: 6.h),
          SizedBox(height: 6.v),
          BlocSelector<PremiumBloc, PremiumState, TextEditingController?>(
              selector: (state) => state.checkmarkController,
              builder: (context, checkmarkController) {
                return CustomTextFormField(
                    controller: checkmarkController,
                    hintText: "msg_improved_recognition".tr,
                    hintStyle: CustomTextStyles.bodySmallBlack90011,
                    textInputAction: TextInputAction.done,
                    suffix: Container(
                        margin: EdgeInsets.only(left: 30.h, bottom: 12.v),
                        child: CustomImageView(
                            imagePath: ImageConstant.imgCheckmark,
                            height: 21.adaptSize,
                            width: 21.adaptSize)),
                    suffixConstraints: BoxConstraints(maxHeight: 33.v),
                    contentPadding:
                        EdgeInsets.only(left: 11.h, top: 6.v, bottom: 6.v),
                    borderDecoration: TextFormFieldStyleHelper.underLineWhiteA,
                    filled: false);
              }),
          Divider(color: appTheme.whiteA700, endIndent: 6.h),
          SizedBox(height: 8.v),
          Padding(
              padding: EdgeInsets.only(left: 11.h, right: 2.h),
              child: BlocSelector<PremiumBloc, PremiumState, bool?>(
                  selector: (state) => state.checkmark,
                  builder: (context, checkmark) {
                    return CustomCheckboxButton(
                        width: 293.h,
                        text: "msg_access_to_10_diseases".tr,
                        value: checkmark,
                        padding: EdgeInsets.symmetric(vertical: 3.v),
                        isRightCheck: true,
                        onChange: (value) {
                          context
                              .read<PremiumBloc>()
                              .add(ChangeCheckBox1Event(value: value));
                        });
                  })),
          SizedBox(height: 9.v),
          Divider(color: appTheme.whiteA700, endIndent: 6.h),
          SizedBox(height: 10.v),
          Padding(
              padding: EdgeInsets.only(left: 11.h, right: 2.h),
              child: BlocSelector<PremiumBloc, PremiumState, bool?>(
                  selector: (state) => state.checkmark1,
                  builder: (context, checkmark1) {
                    return CustomCheckboxButton(
                        width: 293.h,
                        text: "msg_exclusive_access".tr,
                        value: checkmark1,
                        padding: EdgeInsets.symmetric(vertical: 3.v),
                        isRightCheck: true,
                        onChange: (value) {
                          context
                              .read<PremiumBloc>()
                              .add(ChangeCheckBox2Event(value: value));
                        });
                  }))
        ]));
  }

  /// Navigates to the homePageScreen when the action is triggered.
  onTapImage(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.homePageScreen,
    );
  }
}
