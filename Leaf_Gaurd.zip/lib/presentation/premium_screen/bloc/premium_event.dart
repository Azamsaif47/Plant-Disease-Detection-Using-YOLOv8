// ignore_for_file: must_be_immutable

part of 'premium_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///Premium widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class PremiumEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the Premium widget is first created.
class PremiumInitialEvent extends PremiumEvent {
  @override
  List<Object?> get props => [];
}

///Event for changing checkbox
class ChangeCheckBoxEvent extends PremiumEvent {
  ChangeCheckBoxEvent({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}

///Event for changing checkbox
class ChangeCheckBox1Event extends PremiumEvent {
  ChangeCheckBox1Event({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}

///Event for changing checkbox
class ChangeCheckBox2Event extends PremiumEvent {
  ChangeCheckBox2Event({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}
