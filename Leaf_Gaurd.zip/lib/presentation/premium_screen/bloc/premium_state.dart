// ignore_for_file: must_be_immutable

part of 'premium_bloc.dart';

/// Represents the state of Premium in the application.
class PremiumState extends Equatable {
  PremiumState({
    this.checkmarkController,
    this.noAds = false,
    this.checkmark = false,
    this.checkmark1 = false,
    this.premiumModelObj,
  });

  TextEditingController? checkmarkController;

  PremiumModel? premiumModelObj;

  bool noAds;

  bool checkmark;

  bool checkmark1;

  @override
  List<Object?> get props => [
        checkmarkController,
        noAds,
        checkmark,
        checkmark1,
        premiumModelObj,
      ];

  PremiumState copyWith({
    TextEditingController? checkmarkController,
    bool? noAds,
    bool? checkmark,
    bool? checkmark1,
    PremiumModel? premiumModelObj,
  }) {
    return PremiumState(
      checkmarkController: checkmarkController ?? this.checkmarkController,
      noAds: noAds ?? this.noAds,
      checkmark: checkmark ?? this.checkmark,
      checkmark1: checkmark1 ?? this.checkmark1,
      premiumModelObj: premiumModelObj ?? this.premiumModelObj,
    );
  }
}
