import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:farhan_s_application4/presentation/premium_screen/models/premium_model.dart';
part 'premium_event.dart';
part 'premium_state.dart';

/// A bloc that manages the state of a Premium according to the event that is dispatched to it.
class PremiumBloc extends Bloc<PremiumEvent, PremiumState> {
  PremiumBloc(PremiumState initialState) : super(initialState) {
    on<PremiumInitialEvent>(_onInitialize);
    on<ChangeCheckBoxEvent>(_changeCheckBox);
    on<ChangeCheckBox1Event>(_changeCheckBox1);
    on<ChangeCheckBox2Event>(_changeCheckBox2);
  }

  _changeCheckBox(
    ChangeCheckBoxEvent event,
    Emitter<PremiumState> emit,
  ) {
    emit(state.copyWith(noAds: event.value));
  }

  _changeCheckBox1(
    ChangeCheckBox1Event event,
    Emitter<PremiumState> emit,
  ) {
    emit(state.copyWith(checkmark: event.value));
  }

  _changeCheckBox2(
    ChangeCheckBox2Event event,
    Emitter<PremiumState> emit,
  ) {
    emit(state.copyWith(checkmark1: event.value));
  }

  _onInitialize(
    PremiumInitialEvent event,
    Emitter<PremiumState> emit,
  ) async {
    emit(state.copyWith(
        checkmarkController: TextEditingController(),
        noAds: false,
        checkmark: false,
        checkmark1: false));
  }
}
