import 'package:flutter/material.dart';
import 'package:farhan_s_application4/core/app_export.dart';
import 'package:farhan_s_application4/core/utils/validation_functions.dart';
import 'package:farhan_s_application4/widgets/custom_elevated_button.dart';
import 'package:farhan_s_application4/widgets/custom_text_form_field.dart';
import 'bloc/log_in_bloc.dart';
import 'models/log_in_model.dart';

// ignore_for_file: must_be_immutable
class LogInScreen extends StatelessWidget {
  LogInScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<LogInBloc>(
        create: (context) => LogInBloc(LogInState(logInModelObj: LogInModel()))
          ..add(LogInInitialEvent()),
        child: LogInScreen());
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: Form(
                        key: _formKey,
                        child: Container(
                            width: double.maxFinite,
                            padding: EdgeInsets.symmetric(vertical: 6.v),
                            child: Column(children: [
                              SizedBox(height: 38.v),
                              SizedBox(
                                  height: 519.v,
                                  width: double.maxFinite,
                                  child: Stack(
                                      alignment: Alignment.topCenter,
                                      children: [
                                        Align(
                                            alignment: Alignment.topCenter,
                                            child: SizedBox(
                                                width: double.maxFinite,
                                                child: Divider())),
                                        Align(
                                            alignment: Alignment.topCenter,
                                            child: Padding(
                                                padding:
                                                    EdgeInsets.only(top: 19.v),
                                                child: Text("lbl_log_in".tr,
                                                    style: theme.textTheme
                                                        .headlineSmall))),
                                        CustomImageView(
                                            imagePath:
                                                ImageConstant.imgGroupGreen400,
                                            height: 191.v,
                                            width: 116.h,
                                            alignment: Alignment.topLeft,
                                            margin: EdgeInsets.only(left: 3.h)),
                                        Align(
                                            alignment: Alignment.bottomCenter,
                                            child: Padding(
                                                padding: EdgeInsets.symmetric(
                                                    horizontal: 53.h),
                                                child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      Container(
                                                          width: 232.h,
                                                          margin: EdgeInsets
                                                              .symmetric(
                                                                  horizontal:
                                                                      38.h),
                                                          decoration:
                                                              AppDecoration
                                                                  .outlineBlack,
                                                          child: Text(
                                                              "lbl_leaf_guardian"
                                                                  .tr,
                                                              maxLines: null,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              style: theme
                                                                  .textTheme
                                                                  .displaySmall)),
                                                      SizedBox(height: 19.v),
                                                      BlocSelector<
                                                              LogInBloc,
                                                              LogInState,
                                                              TextEditingController?>(
                                                          selector: (state) =>
                                                              state
                                                                  .emailController,
                                                          builder: (context,
                                                              emailController) {
                                                            return CustomTextFormField(
                                                                controller:
                                                                    emailController,
                                                                hintText:
                                                                    "lbl_email"
                                                                        .tr,
                                                                textInputType:
                                                                    TextInputType
                                                                        .emailAddress,
                                                                validator:
                                                                    (value) {
                                                                  if (value ==
                                                                          null ||
                                                                      (!isValidEmail(
                                                                          value,
                                                                          isRequired:
                                                                              true))) {
                                                                    return "err_msg_please_enter_valid_email"
                                                                        .tr;
                                                                  }
                                                                  return null;
                                                                });
                                                          }),
                                                      SizedBox(height: 43.v),
                                                      BlocSelector<
                                                              LogInBloc,
                                                              LogInState,
                                                              TextEditingController?>(
                                                          selector: (state) => state
                                                              .passwordController,
                                                          builder: (context,
                                                              passwordController) {
                                                            return CustomTextFormField(
                                                                controller:
                                                                    passwordController,
                                                                hintText:
                                                                    "lbl_password"
                                                                        .tr,
                                                                textInputAction:
                                                                    TextInputAction
                                                                        .done,
                                                                textInputType:
                                                                    TextInputType
                                                                        .visiblePassword,
                                                                validator:
                                                                    (value) {
                                                                  if (value ==
                                                                          null ||
                                                                      (!isValidPassword(
                                                                          value,
                                                                          isRequired:
                                                                              true))) {
                                                                    return "err_msg_please_enter_valid_password"
                                                                        .tr;
                                                                  }
                                                                  return null;
                                                                },
                                                                obscureText:
                                                                    true);
                                                          }),
                                                      SizedBox(height: 17.v),
                                                      Align(
                                                          alignment: Alignment
                                                              .centerLeft,
                                                          child:
                                                              GestureDetector(
                                                                  onTap: () {
                                                                    onTapTxtForgotPassword(
                                                                        context);
                                                                  },
                                                                  child: Padding(
                                                                      padding: EdgeInsets.only(
                                                                          left: 88
                                                                              .h),
                                                                      child: Text(
                                                                          "msg_forgot_password"
                                                                              .tr,
                                                                          style: theme
                                                                              .textTheme
                                                                              .titleSmall)))),
                                                      SizedBox(height: 53.v),
                                                      CustomElevatedButton(
                                                          width: 172.h,
                                                          text: "lbl_log_in".tr,
                                                          onPressed: () {
                                                            onTapLogIn(context);
                                                          })
                                                    ])))
                                      ])),
                              SizedBox(height: 63.v),
                              Align(
                                  alignment: Alignment.centerRight,
                                  child: Padding(
                                      padding: EdgeInsets.only(
                                          left: 104.h, right: 6.h),
                                      child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            GestureDetector(
                                                onTap: () {
                                                  onTapTxtDonthaveaccount(
                                                      context);
                                                },
                                                child: Padding(
                                                    padding: EdgeInsets.only(
                                                        top: 52.v,
                                                        bottom: 32.v),
                                                    child: RichText(
                                                        text:
                                                            TextSpan(children: [
                                                          TextSpan(
                                                              text:
                                                                  "msg_don_t_have_account2"
                                                                      .tr,
                                                              style: CustomTextStyles
                                                                  .titleSmallff000000),
                                                          TextSpan(text: " "),
                                                          TextSpan(
                                                              text:
                                                                  "lbl_sign_up"
                                                                      .tr,
                                                              style: CustomTextStyles
                                                                  .titleSmallff000000ExtraBold)
                                                        ]),
                                                        textAlign:
                                                            TextAlign.left))),
                                            CustomImageView(
                                                imagePath: ImageConstant
                                                    .imgGroupGreen600,
                                                height: 104.v,
                                                width: 64.h,
                                                margin:
                                                    EdgeInsets.only(left: 47.h))
                                          ])))
                            ])))))));
  }

  /// Navigates to the forgotPasswordScreen when the action is triggered.
  onTapTxtForgotPassword(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.forgotPasswordScreen,
    );
  }

  /// Navigates to the homePageScreen when the action is triggered.
  onTapLogIn(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.homePageScreen,
    );
  }

  /// Navigates to the signUpScreen when the action is triggered.
  onTapTxtDonthaveaccount(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.signUpScreen,
    );
  }
}
