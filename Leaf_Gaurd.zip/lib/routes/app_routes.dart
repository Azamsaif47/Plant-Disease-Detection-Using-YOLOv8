import 'package:flutter/material.dart';
import '../presentation/splash_screen/splash_screen.dart';
import '../presentation/log_in_screen/log_in_screen.dart';
import '../presentation/sign_up_screen/sign_up_screen.dart';
import '../presentation/home_page_screen/home_page_screen.dart';
import '../presentation/premium_screen/premium_screen.dart';
import '../presentation/profile_screen/profile_screen.dart';
import '../presentation/forgot_password_screen/forgot_password_screen.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String splashScreen = '/splash_screen';

  static const String logInScreen = '/log_in_screen';

  static const String signUpScreen = '/sign_up_screen';

  static const String homePageScreen = '/home_page_screen';

  static const String premiumScreen = '/premium_screen';

  static const String profileScreen = '/profile_screen';

  static const String forgotPasswordScreen = '/forgot_password_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        splashScreen: SplashScreen.builder,
        logInScreen: LogInScreen.builder,
        signUpScreen: SignUpScreen.builder,
        homePageScreen: HomePageScreen.builder,
        premiumScreen: PremiumScreen.builder,
        profileScreen: ProfileScreen.builder,
        forgotPasswordScreen: ForgotPasswordScreen.builder,
        appNavigationScreen: AppNavigationScreen.builder,
        initialRoute: SplashScreen.builder
      };
}
