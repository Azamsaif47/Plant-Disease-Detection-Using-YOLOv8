final Map<String, String> enUs = {
  // Splash Screen Screen
  "lbl_to": "to", "lbl_welcome": "Welcome",

  // Log-In Screen
  "lbl_log_in": "Log In",
  "lbl_password": "PASSWORD",
  "msg_don_t_have_account": "Don’t have account? Sign Up",
  "msg_don_t_have_account2": "Don’t have account?",
  "msg_forgot_password": "Forgot Password?",

  // Sign-Up Screen
  "lbl_email_address": "Email Address", "lbl_name": "Name",
  "lbl_password2": "Password",

  // Home Page Screen
  "lbl_antracnose": "ANTRACNOSE",
  "lbl_blight": "Blight",
  "lbl_camera": "CAMERA",
  "lbl_history": "History",
  "lbl_leaf_spot": "LEAF SPOT",
  "lbl_load_more": "Load More",
  "lbl_mosaic_virus": "MOSAIC VIRUS",
  "lbl_today": "Today",
  "lbl_yesterday": "Yesterday",
  "msg_antracnose_detected":
      "ANTRACNOSE, detected through gallery upload, at 06:50 PM 31/January/2024",
  "msg_blight_detected":
      "Blight, detected through camera scan, at 07:55 AM 30/January/2024",
  "msg_describe_a_disease": "Describe a disease via",
  "msg_detected_through":
      ", detected through camera scan, at 06:52 PM 31/January/2024",
  "msg_detected_through2":
      ", detected through gallery upload, at 06:50 PM 31/January/2024",
  "msg_detected_through3":
      ", detected through camera scan, at 03:22 PM 30/January/2024",
  "msg_detected_through4":
      ", detected through camera scan, at 07:55 AM 30/January/2024",
  "msg_illuminate_the_ailment": "Illuminate the ailment \nin a single stride.",
  "msg_leaf_spot_detected":
      "LEAF SPOT, detected through camera scan, at 06:52 PM 31/January/2024",
  "msg_mosaic_virus_detected":
      "MOSAIC VIRUS, detected through camera scan, at 03:22 PM 30/January/2024",
  "msg_upload_from_gallery": "Upload from gallery",

  // premium Screen
  "lbl_buy_premium": "Buy Premium",
  "lbl_no_ads": "No ads",
  "lbl_premium_version": "Premium Version",
  "msg_access_to_10_diseases": "Access to 10+ diseases, 100+ plant species.",
  "msg_ai_safeguarding": "AI safeguarding plant\nhealth",
  "msg_exclusive_access": "Exclusive access to expert botany knowledge",
  "msg_improved_recognition":
      "Improved recognition accuracy with subscription.",
  "msg_plant_care_now": "Plant care, now 75% more affordable with ",

  // Profile Screen
  "lbl_about_us": "About Us",
  "lbl_azam_saif": "AZAM SAIF",
  "lbl_privacy_policy": "Privacy Policy",
  "lbl_profile": "Profile",
  "lbl_settings": "Settings",
  "lbl_share": "Share",
  "msg_azamsaif123_gmail_com": "azamsaif123@gmail.com",
  "msg_costumer_support": "Costumer Support",

  // Forgot Password Screen
  "lbl_change_password": "Change Password",
  "lbl_forgot_password": "Forgot Password",
  "lbl_get_code": "Get Code",
  "lbl_new_password": "New Password",
  "msg_confirmation_code": "Confirmation Code",
  "msg_continue_using_your": "Continue using your Email",

  // Common String
  "lbl_email": "EMAIL",
  "lbl_leaf_guardian": "Leaf-Guardian",
  "lbl_sign_up": "Sign Up",
  "msg_confirm_password": "Confirm Password",
  "msg_terms_and_conditions": "Terms and conditions",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",

  // Validation Error String
  "err_msg_please_enter_valid_email": "Please enter valid email",
  "err_msg_please_enter_valid_password": "Please enter valid password",
  "err_msg_please_enter_valid_text": "Please enter valid text",
};
