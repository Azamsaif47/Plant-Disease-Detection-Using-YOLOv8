class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Splash Screen images
  static String imgGroup = '$imagePath/img_group.png';

  static String imgVector = '$imagePath/img_vector.svg';

  // Log-In images
  static String imgGroupGreen400 = '$imagePath/img_group_green_400.svg';

  static String imgGroupGreen600 = '$imagePath/img_group_green_600.svg';

  // Sign-Up images
  static String imgGroupBlack900 = '$imagePath/img_group_black_900.svg';

  // Home Page images
  static String imgClose = '$imagePath/img_close.svg';

  static String imgLock = '$imagePath/img_lock.svg';

  static String imgCameraMinimali = '$imagePath/img_camera_minimali.svg';

  static String imgOnprimary = '$imagePath/img__onprimary.svg';

  static String imgFrame = '$imagePath/img_frame.svg';

  static String imgGroupCyan900 = '$imagePath/img_group_cyan_900.svg';

  static String imgGroupRed700 = '$imagePath/img_group_red_700.png';

  static String imgVectorOrange100 = '$imagePath/img_vector_orange_100.png';

  static String imgCloseWhiteA700 = '$imagePath/img_close_white_a700.png';

  static String imgEllipse3 = '$imagePath/img_ellipse_3.png';

  // premium images
  static String imgCheckmark = '$imagePath/img_checkmark.svg';

  // Profile images
  static String imgGroup14 = '$imagePath/img_group_14.svg';

  static String imgSupportSvgrepoCom = '$imagePath/img_support_svgrepo_com.svg';

  static String imgSearch = '$imagePath/img_search.svg';

  static String imgAboutSvgrepoCom = '$imagePath/img_about_svgrepo_com.svg';

  // Forgot Password images
  static String imgCloseBlack900 = '$imagePath/img_close_black_900.svg';

  // Common images
  static String imgEllipse1 = '$imagePath/img_ellipse_1.png';

  static String img = '$imagePath/img_.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
